# Book-Exchange-For-Freshers
Gives a platform to Freshers to buy books from Seniors
